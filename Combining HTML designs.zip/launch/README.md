# Launching All Things Angela — Step by Step

## 1. Host the site (free)
1. Go to https://dash.cloudflare.com -> Workers & Pages -> Create -> Pages -> Upload assets (or connect a Git repo).
2. Upload the whole project folder (this gives you a free `yourproject.pages.dev` URL immediately).
3. Optional: once you own a domain, attach it in Pages -> Custom domains.

## 2. Get an Anthropic API key
1. Sign up at https://console.anthropic.com
2. Create an API key (Settings -> API Keys). Anthropic bills pay-as-you-go — no monthly fee, you only pay for what you use (see cost notes below).

## 3. Deploy the Claude proxy Worker
This keeps your API key secret (never exposed in the browser).
1. In Cloudflare: Workers & Pages -> Create -> Worker.
2. Paste in the contents of `claude-proxy-worker.js` (in this folder).
3. Worker -> Settings -> Variables and Secrets -> add secret `ANTHROPIC_API_KEY` = your real key.
4. Deploy. Copy the Worker's URL, e.g. `https://claude-proxy.yoursubdomain.workers.dev`.

## 4. Point the site at your Worker
Each of these files has a line near the top of its `<script>`:
```js
const CLAUDE_PROXY_URL = ""; // fill in after deploying your Worker
```
Set it to your Worker's URL in:
- `pages/storymind.html`
- `pages/human-check.html`
- `pages/wealth-council.html` (loads `wealth-council.jsx`, which has the same line)
- `All Things Angela.dc.html` (the hub's support chatbot)

Once set, the AI features (story generation, the Wealth Council, the Human Check pre-audit, the hub chatbot) will work live — they automatically use the Worker once deployed, and keep using the free in-tool helper only while you're still working inside this design tool.

## 5. Email + payments (already set up)
- Contact forms already point to `allthingsangela@zohomail.com` via mailto.
- Checkout/payment flows show your Venmo handle `@AllThingsAngela1995` and notify you by email — no payment automation is wired in (Venmo has no API for individuals). If you want automated payment collection later, replace this with Stripe Payment Links.

## Cost recap
- Hosting: $0 (Cloudflare Pages free tier)
- Worker: $0 (Cloudflare Workers free tier, 100k requests/day)
- Anthropic API: pay-as-you-go, no monthly fee — Haiku (cheapest model, used everywhere here) costs $1/$5 per million input/output tokens. Realistic early usage: a few dollars a month at most.
- Domain (optional): ~$10-15/year if you buy one later.
