// Cloudflare Worker: Claude API proxy
// -------------------------------------------------
// This keeps your Anthropic API key on the server, never in the browser.
// The site's pages call this Worker instead of Anthropic directly.
//
// DEPLOY STEPS:
// 1. Go to https://dash.cloudflare.com -> Workers & Pages -> Create -> Worker.
// 2. Paste this whole file in as the Worker's code (replacing the sample).
// 3. Go to the Worker's Settings -> Variables -> add a secret named
//    ANTHROPIC_API_KEY with your real key from https://console.anthropic.com
// 4. Deploy. You'll get a URL like https://claude-proxy.YOURSUBDOMAIN.workers.dev
// 5. Paste that URL into CLAUDE_PROXY_URL in each site page (see README).

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders() });
    }
    if (request.method !== "POST") {
      return new Response("Method not allowed", { status: 405, headers: corsHeaders() });
    }

    try {
      const body = await request.json();

      const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: body.model || "claude-haiku-4-5",
          max_tokens: body.max_tokens || 1024,
          system: body.system,
          messages: body.messages,
        }),
      });

      const data = await anthropicRes.json();

      if (data.error) {
        return new Response(JSON.stringify({ error: data.error.message || "Anthropic API error" }), {
          status: 500,
          headers: corsHeaders(),
        });
      }

      const text = (data.content || [])
        .filter((b) => b.type === "text")
        .map((b) => b.text)
        .join("\n");

      return new Response(JSON.stringify({ text }), { headers: corsHeaders() });
    } catch (err) {
      return new Response(JSON.stringify({ error: err.message || "Proxy error" }), {
        status: 500,
        headers: corsHeaders(),
      });
    }
  },
};

function corsHeaders() {
  return {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };
}
